# basic-setup
basic setup for react / node project
