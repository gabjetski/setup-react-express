import * as React from 'react';

const TestComponent = () => {
    return (
        <div>
            Hi
        </div>
    );
}

export default TestComponent;