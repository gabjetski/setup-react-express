import React from "react";
import TestComponent from "./components/TestComponent.jsx"

const App = () => {
    return (
        <div>
          <TestComponent />
        </div>
    )
}

export default App;